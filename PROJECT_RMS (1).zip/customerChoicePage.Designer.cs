﻿
namespace PROJECT_RMS
{
    partial class customerChoicePage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.lbOrder = new System.Windows.Forms.Label();
            this.lbTR = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lbBack = new System.Windows.Forms.Label();
            this.lbUpdateItem = new System.Windows.Forms.Label();
            this.lbADDitem = new System.Windows.Forms.Label();
            this.lbremove = new System.Windows.Forms.Label();
            this.lbSLPback = new System.Windows.Forms.Label();
            this.lbSinfo = new System.Windows.Forms.Label();
            this.lbBOOKINGinfo = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(435, 93);
            this.panel1.TabIndex = 0;
            // 
            // lbOrder
            // 
            this.lbOrder.AutoSize = true;
            this.lbOrder.Font = new System.Drawing.Font("Britannic Bold", 15.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbOrder.Location = new System.Drawing.Point(170, 122);
            this.lbOrder.Name = "lbOrder";
            this.lbOrder.Size = new System.Drawing.Size(75, 23);
            this.lbOrder.TabIndex = 1;
            this.lbOrder.Text = "ORDER";
            this.lbOrder.Click += new System.EventHandler(this.lbOrder_Click);
            // 
            // lbTR
            // 
            this.lbTR.AutoSize = true;
            this.lbTR.Font = new System.Drawing.Font("Britannic Bold", 15.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTR.Location = new System.Drawing.Point(119, 160);
            this.lbTR.Name = "lbTR";
            this.lbTR.Size = new System.Drawing.Size(200, 23);
            this.lbTR.TabIndex = 2;
            this.lbTR.Text = "TABLE RESERVATION";
            this.lbTR.Click += new System.EventHandler(this.lbTR_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.panel2.Location = new System.Drawing.Point(-5, 426);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(440, 85);
            this.panel2.TabIndex = 3;
            // 
            // lbBack
            // 
            this.lbBack.AutoSize = true;
            this.lbBack.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbBack.Location = new System.Drawing.Point(190, 405);
            this.lbBack.Name = "lbBack";
            this.lbBack.Size = new System.Drawing.Size(55, 18);
            this.lbBack.TabIndex = 4;
            this.lbBack.Text = "BACK";
            this.lbBack.Click += new System.EventHandler(this.lbBack_Click);
            // 
            // lbUpdateItem
            // 
            this.lbUpdateItem.AutoSize = true;
            this.lbUpdateItem.Font = new System.Drawing.Font("Britannic Bold", 15.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbUpdateItem.Location = new System.Drawing.Point(152, 230);
            this.lbUpdateItem.Name = "lbUpdateItem";
            this.lbUpdateItem.Size = new System.Drawing.Size(133, 23);
            this.lbUpdateItem.TabIndex = 5;
            this.lbUpdateItem.Text = "UPDATE ITEM";
            this.lbUpdateItem.Click += new System.EventHandler(this.lbUpdateItem_Click);
            // 
            // lbADDitem
            // 
            this.lbADDitem.AutoSize = true;
            this.lbADDitem.Font = new System.Drawing.Font("Britannic Bold", 15.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbADDitem.Location = new System.Drawing.Point(170, 197);
            this.lbADDitem.Name = "lbADDitem";
            this.lbADDitem.Size = new System.Drawing.Size(99, 23);
            this.lbADDitem.TabIndex = 6;
            this.lbADDitem.Text = "ADD ITEM";
            this.lbADDitem.Click += new System.EventHandler(this.lbADDitem_Click);
            // 
            // lbremove
            // 
            this.lbremove.AutoSize = true;
            this.lbremove.Font = new System.Drawing.Font("Britannic Bold", 15.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbremove.Location = new System.Drawing.Point(150, 270);
            this.lbremove.Name = "lbremove";
            this.lbremove.Size = new System.Drawing.Size(135, 23);
            this.lbremove.TabIndex = 7;
            this.lbremove.Text = "REMOVE ITEM";
            this.lbremove.Click += new System.EventHandler(this.lbremove_Click);
            // 
            // lbSLPback
            // 
            this.lbSLPback.AutoSize = true;
            this.lbSLPback.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbSLPback.Location = new System.Drawing.Point(190, 378);
            this.lbSLPback.Name = "lbSLPback";
            this.lbSLPback.Size = new System.Drawing.Size(55, 18);
            this.lbSLPback.TabIndex = 8;
            this.lbSLPback.Text = "BACK";
            this.lbSLPback.Click += new System.EventHandler(this.lbSLPback_Click);
            // 
            // lbSinfo
            // 
            this.lbSinfo.AutoSize = true;
            this.lbSinfo.Font = new System.Drawing.Font("Britannic Bold", 15.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbSinfo.Location = new System.Drawing.Point(121, 307);
            this.lbSinfo.Name = "lbSinfo";
            this.lbSinfo.Size = new System.Drawing.Size(198, 23);
            this.lbSinfo.TabIndex = 9;
            this.lbSinfo.Text = "STAFF INFORMATION";
            this.lbSinfo.Click += new System.EventHandler(this.lbSinfo_Click);
            // 
            // lbBOOKINGinfo
            // 
            this.lbBOOKINGinfo.AutoSize = true;
            this.lbBOOKINGinfo.Font = new System.Drawing.Font("Britannic Bold", 15.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbBOOKINGinfo.Location = new System.Drawing.Point(152, 343);
            this.lbBOOKINGinfo.Name = "lbBOOKINGinfo";
            this.lbBOOKINGinfo.Size = new System.Drawing.Size(147, 23);
            this.lbBOOKINGinfo.TabIndex = 10;
            this.lbBOOKINGinfo.Text = "BOOKING INFO";
            this.lbBOOKINGinfo.Click += new System.EventHandler(this.lbBOOKINGinfo_Click);
            // 
            // customerChoicePage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightGreen;
            this.ClientSize = new System.Drawing.Size(434, 509);
            this.Controls.Add(this.lbBOOKINGinfo);
            this.Controls.Add(this.lbSinfo);
            this.Controls.Add(this.lbSLPback);
            this.Controls.Add(this.lbremove);
            this.Controls.Add(this.lbADDitem);
            this.Controls.Add(this.lbUpdateItem);
            this.Controls.Add(this.lbBack);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.lbTR);
            this.Controls.Add(this.lbOrder);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "customerChoicePage";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "customerChoicePage";
            this.Load += new System.EventHandler(this.customerChoicePage_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lbOrder;
        private System.Windows.Forms.Label lbTR;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lbBack;
        private System.Windows.Forms.Label lbUpdateItem;
        private System.Windows.Forms.Label lbADDitem;
        private System.Windows.Forms.Label lbremove;
        private System.Windows.Forms.Label lbSLPback;
        private System.Windows.Forms.Label lbSinfo;
        private System.Windows.Forms.Label lbBOOKINGinfo;
    }
}