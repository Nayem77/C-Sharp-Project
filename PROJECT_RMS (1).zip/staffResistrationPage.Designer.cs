﻿
namespace PROJECT_RMS
{
    partial class staffResistrationPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtSaddress = new System.Windows.Forms.TextBox();
            this.txtSmail = new System.Windows.Forms.TextBox();
            this.txtSRPASSWORD = new System.Windows.Forms.TextBox();
            this.txtSRUN = new System.Windows.Forms.TextBox();
            this.txtSRN = new System.Windows.Forms.TextBox();
            this.lbSaddress = new System.Windows.Forms.Label();
            this.lbSemail = new System.Windows.Forms.Label();
            this.lbSRPASSWORD = new System.Windows.Forms.Label();
            this.lbSRUN = new System.Windows.Forms.Label();
            this.lbSRN = new System.Windows.Forms.Label();
            this.lbSR = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.rbSFEMALE = new System.Windows.Forms.RadioButton();
            this.rbSMALE = new System.Windows.Forms.RadioButton();
            this.lbSGENDER = new System.Windows.Forms.Label();
            this.lbSPOSITON = new System.Windows.Forms.Label();
            this.rbMANGER = new System.Windows.Forms.RadioButton();
            this.rbCHEF = new System.Windows.Forms.RadioButton();
            this.rbWAITER = new System.Windows.Forms.RadioButton();
            this.rbCLEANER = new System.Windows.Forms.RadioButton();
            this.lbSJD = new System.Windows.Forms.Label();
            this.dtpSJD = new System.Windows.Forms.DateTimePicker();
            this.lbSRback = new System.Windows.Forms.Label();
            this.btSsignUP = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtSaddress
            // 
            this.txtSaddress.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.txtSaddress.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtSaddress.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtSaddress.Font = new System.Drawing.Font("Modern No. 20", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSaddress.Location = new System.Drawing.Point(203, 250);
            this.txtSaddress.Name = "txtSaddress";
            this.txtSaddress.Size = new System.Drawing.Size(188, 14);
            this.txtSaddress.TabIndex = 24;
            this.txtSaddress.TextChanged += new System.EventHandler(this.txtSaddress_TextChanged);
            // 
            // txtSmail
            // 
            this.txtSmail.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.txtSmail.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtSmail.CharacterCasing = System.Windows.Forms.CharacterCasing.Lower;
            this.txtSmail.Font = new System.Drawing.Font("Modern No. 20", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSmail.Location = new System.Drawing.Point(203, 207);
            this.txtSmail.Name = "txtSmail";
            this.txtSmail.Size = new System.Drawing.Size(188, 14);
            this.txtSmail.TabIndex = 23;
            // 
            // txtSRPASSWORD
            // 
            this.txtSRPASSWORD.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.txtSRPASSWORD.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtSRPASSWORD.Font = new System.Drawing.Font("Modern No. 20", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSRPASSWORD.Location = new System.Drawing.Point(203, 171);
            this.txtSRPASSWORD.Name = "txtSRPASSWORD";
            this.txtSRPASSWORD.PasswordChar = '.';
            this.txtSRPASSWORD.Size = new System.Drawing.Size(188, 14);
            this.txtSRPASSWORD.TabIndex = 22;
            // 
            // txtSRUN
            // 
            this.txtSRUN.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.txtSRUN.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtSRUN.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtSRUN.Font = new System.Drawing.Font("Modern No. 20", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSRUN.Location = new System.Drawing.Point(203, 137);
            this.txtSRUN.Name = "txtSRUN";
            this.txtSRUN.Size = new System.Drawing.Size(188, 14);
            this.txtSRUN.TabIndex = 21;
            // 
            // txtSRN
            // 
            this.txtSRN.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.txtSRN.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtSRN.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtSRN.Font = new System.Drawing.Font("Modern No. 20", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSRN.Location = new System.Drawing.Point(203, 90);
            this.txtSRN.Name = "txtSRN";
            this.txtSRN.Size = new System.Drawing.Size(188, 14);
            this.txtSRN.TabIndex = 20;
            // 
            // lbSaddress
            // 
            this.lbSaddress.AutoSize = true;
            this.lbSaddress.Font = new System.Drawing.Font("Monotype Corsiva", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbSaddress.Location = new System.Drawing.Point(78, 245);
            this.lbSaddress.Name = "lbSaddress";
            this.lbSaddress.Size = new System.Drawing.Size(107, 22);
            this.lbSaddress.TabIndex = 19;
            this.lbSaddress.Text = "ADDRESS :";
            // 
            // lbSemail
            // 
            this.lbSemail.AutoSize = true;
            this.lbSemail.Font = new System.Drawing.Font("Monotype Corsiva", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbSemail.Location = new System.Drawing.Point(101, 207);
            this.lbSemail.Name = "lbSemail";
            this.lbSemail.Size = new System.Drawing.Size(84, 22);
            this.lbSemail.TabIndex = 18;
            this.lbSemail.Text = "EMAIL :";
            // 
            // lbSRPASSWORD
            // 
            this.lbSRPASSWORD.AutoSize = true;
            this.lbSRPASSWORD.Font = new System.Drawing.Font("Monotype Corsiva", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbSRPASSWORD.Location = new System.Drawing.Point(64, 171);
            this.lbSRPASSWORD.Name = "lbSRPASSWORD";
            this.lbSRPASSWORD.Size = new System.Drawing.Size(121, 22);
            this.lbSRPASSWORD.TabIndex = 17;
            this.lbSRPASSWORD.Text = "PASSWORD :";
            // 
            // lbSRUN
            // 
            this.lbSRUN.AutoSize = true;
            this.lbSRUN.Font = new System.Drawing.Font("Monotype Corsiva", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbSRUN.Location = new System.Drawing.Point(52, 129);
            this.lbSRUN.Name = "lbSRUN";
            this.lbSRUN.Size = new System.Drawing.Size(133, 22);
            this.lbSRUN.TabIndex = 16;
            this.lbSRUN.Text = "USER NAME :";
            // 
            // lbSRN
            // 
            this.lbSRN.AutoSize = true;
            this.lbSRN.Font = new System.Drawing.Font("Monotype Corsiva", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbSRN.Location = new System.Drawing.Point(107, 89);
            this.lbSRN.Name = "lbSRN";
            this.lbSRN.Size = new System.Drawing.Size(78, 22);
            this.lbSRN.TabIndex = 15;
            this.lbSRN.Text = "NAME :";
            // 
            // lbSR
            // 
            this.lbSR.AutoSize = true;
            this.lbSR.Font = new System.Drawing.Font("Algerian", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbSR.Location = new System.Drawing.Point(87, 13);
            this.lbSR.Name = "lbSR";
            this.lbSR.Size = new System.Drawing.Size(238, 24);
            this.lbSR.TabIndex = 14;
            this.lbSR.Text = "STAFF RESISTRATION";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.rbSFEMALE);
            this.panel1.Controls.Add(this.rbSMALE);
            this.panel1.Controls.Add(this.lbSGENDER);
            this.panel1.Location = new System.Drawing.Point(0, 270);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(451, 61);
            this.panel1.TabIndex = 25;
            // 
            // rbSFEMALE
            // 
            this.rbSFEMALE.AutoSize = true;
            this.rbSFEMALE.Font = new System.Drawing.Font("Monotype Corsiva", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbSFEMALE.Location = new System.Drawing.Point(327, 18);
            this.rbSFEMALE.Name = "rbSFEMALE";
            this.rbSFEMALE.Size = new System.Drawing.Size(82, 19);
            this.rbSFEMALE.TabIndex = 28;
            this.rbSFEMALE.TabStop = true;
            this.rbSFEMALE.Text = "FEMALE";
            this.rbSFEMALE.UseVisualStyleBackColor = true;
            // 
            // rbSMALE
            // 
            this.rbSMALE.AutoSize = true;
            this.rbSMALE.Font = new System.Drawing.Font("Monotype Corsiva", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbSMALE.Location = new System.Drawing.Point(212, 18);
            this.rbSMALE.Name = "rbSMALE";
            this.rbSMALE.Size = new System.Drawing.Size(64, 19);
            this.rbSMALE.TabIndex = 27;
            this.rbSMALE.TabStop = true;
            this.rbSMALE.Text = "MALE";
            this.rbSMALE.UseVisualStyleBackColor = true;
            // 
            // lbSGENDER
            // 
            this.lbSGENDER.AutoSize = true;
            this.lbSGENDER.Font = new System.Drawing.Font("Monotype Corsiva", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbSGENDER.Location = new System.Drawing.Point(85, 15);
            this.lbSGENDER.Name = "lbSGENDER";
            this.lbSGENDER.Size = new System.Drawing.Size(100, 22);
            this.lbSGENDER.TabIndex = 26;
            this.lbSGENDER.Text = "GENDER :";
            // 
            // lbSPOSITON
            // 
            this.lbSPOSITON.AutoSize = true;
            this.lbSPOSITON.Font = new System.Drawing.Font("Monotype Corsiva", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbSPOSITON.Location = new System.Drawing.Point(86, 348);
            this.lbSPOSITON.Name = "lbSPOSITON";
            this.lbSPOSITON.Size = new System.Drawing.Size(99, 22);
            this.lbSPOSITON.TabIndex = 26;
            this.lbSPOSITON.Text = "POSITON :";
            // 
            // rbMANGER
            // 
            this.rbMANGER.AutoSize = true;
            this.rbMANGER.Font = new System.Drawing.Font("Monotype Corsiva", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbMANGER.Location = new System.Drawing.Point(212, 352);
            this.rbMANGER.Name = "rbMANGER";
            this.rbMANGER.Size = new System.Drawing.Size(83, 19);
            this.rbMANGER.TabIndex = 27;
            this.rbMANGER.TabStop = true;
            this.rbMANGER.Text = "MANGER";
            this.rbMANGER.UseVisualStyleBackColor = true;
            // 
            // rbCHEF
            // 
            this.rbCHEF.AutoSize = true;
            this.rbCHEF.Font = new System.Drawing.Font("Monotype Corsiva", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbCHEF.Location = new System.Drawing.Point(327, 352);
            this.rbCHEF.Name = "rbCHEF";
            this.rbCHEF.Size = new System.Drawing.Size(61, 19);
            this.rbCHEF.TabIndex = 28;
            this.rbCHEF.TabStop = true;
            this.rbCHEF.Text = "CHEF";
            this.rbCHEF.UseVisualStyleBackColor = true;
            // 
            // rbWAITER
            // 
            this.rbWAITER.AutoSize = true;
            this.rbWAITER.Font = new System.Drawing.Font("Monotype Corsiva", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbWAITER.Location = new System.Drawing.Point(212, 387);
            this.rbWAITER.Name = "rbWAITER";
            this.rbWAITER.Size = new System.Drawing.Size(78, 19);
            this.rbWAITER.TabIndex = 29;
            this.rbWAITER.TabStop = true;
            this.rbWAITER.Text = "WAITER";
            this.rbWAITER.UseVisualStyleBackColor = true;
            // 
            // rbCLEANER
            // 
            this.rbCLEANER.AutoSize = true;
            this.rbCLEANER.Font = new System.Drawing.Font("Monotype Corsiva", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbCLEANER.Location = new System.Drawing.Point(327, 387);
            this.rbCLEANER.Name = "rbCLEANER";
            this.rbCLEANER.Size = new System.Drawing.Size(88, 19);
            this.rbCLEANER.TabIndex = 30;
            this.rbCLEANER.TabStop = true;
            this.rbCLEANER.Text = "CLEANER";
            this.rbCLEANER.UseVisualStyleBackColor = true;
            // 
            // lbSJD
            // 
            this.lbSJD.AutoSize = true;
            this.lbSJD.Font = new System.Drawing.Font("Monotype Corsiva", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbSJD.Location = new System.Drawing.Point(42, 415);
            this.lbSJD.Name = "lbSJD";
            this.lbSJD.Size = new System.Drawing.Size(143, 22);
            this.lbSJD.TabIndex = 31;
            this.lbSJD.Text = "JOINING DAY :";
            // 
            // dtpSJD
            // 
            this.dtpSJD.CalendarMonthBackground = System.Drawing.Color.Firebrick;
            this.dtpSJD.Location = new System.Drawing.Point(215, 417);
            this.dtpSJD.Name = "dtpSJD";
            this.dtpSJD.Size = new System.Drawing.Size(200, 20);
            this.dtpSJD.TabIndex = 32;
            // 
            // lbSRback
            // 
            this.lbSRback.AutoSize = true;
            this.lbSRback.BackColor = System.Drawing.Color.OliveDrab;
            this.lbSRback.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbSRback.Location = new System.Drawing.Point(212, 510);
            this.lbSRback.Name = "lbSRback";
            this.lbSRback.Size = new System.Drawing.Size(55, 18);
            this.lbSRback.TabIndex = 34;
            this.lbSRback.Text = "BACK";
            this.lbSRback.Click += new System.EventHandler(this.lbSRback_Click);
            // 
            // btSsignUP
            // 
            this.btSsignUP.BackColor = System.Drawing.Color.DarkCyan;
            this.btSsignUP.Font = new System.Drawing.Font("Algerian", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btSsignUP.Location = new System.Drawing.Point(198, 468);
            this.btSsignUP.Name = "btSsignUP";
            this.btSsignUP.Size = new System.Drawing.Size(92, 23);
            this.btSsignUP.TabIndex = 33;
            this.btSsignUP.Text = "SIGN UP";
            this.btSsignUP.UseVisualStyleBackColor = false;
            this.btSsignUP.Click += new System.EventHandler(this.btSsignUP_Click);
            // 
            // staffResistrationPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightGreen;
            this.ClientSize = new System.Drawing.Size(450, 550);
            this.Controls.Add(this.lbSRback);
            this.Controls.Add(this.btSsignUP);
            this.Controls.Add(this.dtpSJD);
            this.Controls.Add(this.lbSJD);
            this.Controls.Add(this.rbCLEANER);
            this.Controls.Add(this.rbWAITER);
            this.Controls.Add(this.rbCHEF);
            this.Controls.Add(this.rbMANGER);
            this.Controls.Add(this.lbSPOSITON);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.txtSaddress);
            this.Controls.Add(this.txtSmail);
            this.Controls.Add(this.txtSRPASSWORD);
            this.Controls.Add(this.txtSRUN);
            this.Controls.Add(this.txtSRN);
            this.Controls.Add(this.lbSaddress);
            this.Controls.Add(this.lbSemail);
            this.Controls.Add(this.lbSRPASSWORD);
            this.Controls.Add(this.lbSRUN);
            this.Controls.Add(this.lbSRN);
            this.Controls.Add(this.lbSR);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "staffResistrationPage";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "staffResistrationPage";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtSaddress;
        private System.Windows.Forms.TextBox txtSmail;
        private System.Windows.Forms.TextBox txtSRPASSWORD;
        private System.Windows.Forms.TextBox txtSRUN;
        private System.Windows.Forms.TextBox txtSRN;
        private System.Windows.Forms.Label lbSaddress;
        private System.Windows.Forms.Label lbSemail;
        private System.Windows.Forms.Label lbSRPASSWORD;
        private System.Windows.Forms.Label lbSRUN;
        private System.Windows.Forms.Label lbSRN;
        private System.Windows.Forms.Label lbSR;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.RadioButton rbSFEMALE;
        private System.Windows.Forms.RadioButton rbSMALE;
        private System.Windows.Forms.Label lbSGENDER;
        private System.Windows.Forms.Label lbSPOSITON;
        private System.Windows.Forms.RadioButton rbMANGER;
        private System.Windows.Forms.RadioButton rbCHEF;
        private System.Windows.Forms.RadioButton rbWAITER;
        private System.Windows.Forms.RadioButton rbCLEANER;
        private System.Windows.Forms.Label lbSJD;
        private System.Windows.Forms.DateTimePicker dtpSJD;
        private System.Windows.Forms.Label lbSRback;
        private System.Windows.Forms.Button btSsignUP;
    }
}