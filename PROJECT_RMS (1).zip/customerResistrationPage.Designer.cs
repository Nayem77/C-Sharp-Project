﻿
namespace PROJECT_RMS
{
    partial class customerResistrationPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbCR = new System.Windows.Forms.Label();
            this.lbCRN = new System.Windows.Forms.Label();
            this.lbCRUN = new System.Windows.Forms.Label();
            this.lbCRPASSWORD = new System.Windows.Forms.Label();
            this.lbCemail = new System.Windows.Forms.Label();
            this.lbCaddress = new System.Windows.Forms.Label();
            this.lbCGENDER = new System.Windows.Forms.Label();
            this.lbCDOB = new System.Windows.Forms.Label();
            this.dtpDOB = new System.Windows.Forms.DateTimePicker();
            this.txtCRN = new System.Windows.Forms.TextBox();
            this.txtCRUN = new System.Windows.Forms.TextBox();
            this.txtCRPASSWORD = new System.Windows.Forms.TextBox();
            this.txtCmail = new System.Windows.Forms.TextBox();
            this.txtCaddress = new System.Windows.Forms.TextBox();
            this.rbCMALE = new System.Windows.Forms.RadioButton();
            this.rbCFEMALE = new System.Windows.Forms.RadioButton();
            this.btCsignUP = new System.Windows.Forms.Button();
            this.lbCRback = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbCR
            // 
            this.lbCR.AutoSize = true;
            this.lbCR.Font = new System.Drawing.Font("Algerian", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCR.Location = new System.Drawing.Point(84, 9);
            this.lbCR.Name = "lbCR";
            this.lbCR.Size = new System.Drawing.Size(280, 24);
            this.lbCR.TabIndex = 0;
            this.lbCR.Text = "CUSTOMER RESISTRATION";
            // 
            // lbCRN
            // 
            this.lbCRN.AutoSize = true;
            this.lbCRN.Font = new System.Drawing.Font("Monotype Corsiva", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCRN.Location = new System.Drawing.Point(104, 85);
            this.lbCRN.Name = "lbCRN";
            this.lbCRN.Size = new System.Drawing.Size(78, 22);
            this.lbCRN.TabIndex = 1;
            this.lbCRN.Text = "NAME :";
            // 
            // lbCRUN
            // 
            this.lbCRUN.AutoSize = true;
            this.lbCRUN.Font = new System.Drawing.Font("Monotype Corsiva", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCRUN.Location = new System.Drawing.Point(49, 125);
            this.lbCRUN.Name = "lbCRUN";
            this.lbCRUN.Size = new System.Drawing.Size(133, 22);
            this.lbCRUN.TabIndex = 2;
            this.lbCRUN.Text = "USER NAME :";
            // 
            // lbCRPASSWORD
            // 
            this.lbCRPASSWORD.AutoSize = true;
            this.lbCRPASSWORD.Font = new System.Drawing.Font("Monotype Corsiva", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCRPASSWORD.Location = new System.Drawing.Point(61, 167);
            this.lbCRPASSWORD.Name = "lbCRPASSWORD";
            this.lbCRPASSWORD.Size = new System.Drawing.Size(121, 22);
            this.lbCRPASSWORD.TabIndex = 3;
            this.lbCRPASSWORD.Text = "PASSWORD :";
            // 
            // lbCemail
            // 
            this.lbCemail.AutoSize = true;
            this.lbCemail.Font = new System.Drawing.Font("Monotype Corsiva", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCemail.Location = new System.Drawing.Point(98, 203);
            this.lbCemail.Name = "lbCemail";
            this.lbCemail.Size = new System.Drawing.Size(84, 22);
            this.lbCemail.TabIndex = 4;
            this.lbCemail.Text = "EMAIL :";
            // 
            // lbCaddress
            // 
            this.lbCaddress.AutoSize = true;
            this.lbCaddress.Font = new System.Drawing.Font("Monotype Corsiva", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCaddress.Location = new System.Drawing.Point(75, 241);
            this.lbCaddress.Name = "lbCaddress";
            this.lbCaddress.Size = new System.Drawing.Size(107, 22);
            this.lbCaddress.TabIndex = 5;
            this.lbCaddress.Text = "ADDRESS :";
            // 
            // lbCGENDER
            // 
            this.lbCGENDER.AutoSize = true;
            this.lbCGENDER.Font = new System.Drawing.Font("Monotype Corsiva", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCGENDER.Location = new System.Drawing.Point(82, 289);
            this.lbCGENDER.Name = "lbCGENDER";
            this.lbCGENDER.Size = new System.Drawing.Size(100, 22);
            this.lbCGENDER.TabIndex = 6;
            this.lbCGENDER.Text = "GENDER :";
            // 
            // lbCDOB
            // 
            this.lbCDOB.AutoSize = true;
            this.lbCDOB.Font = new System.Drawing.Font("Monotype Corsiva", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCDOB.Location = new System.Drawing.Point(19, 335);
            this.lbCDOB.Name = "lbCDOB";
            this.lbCDOB.Size = new System.Drawing.Size(163, 22);
            this.lbCDOB.TabIndex = 7;
            this.lbCDOB.Text = "DATE OF BIRTH :";
            // 
            // dtpDOB
            // 
            this.dtpDOB.CalendarMonthBackground = System.Drawing.Color.Firebrick;
            this.dtpDOB.Location = new System.Drawing.Point(188, 337);
            this.dtpDOB.Name = "dtpDOB";
            this.dtpDOB.Size = new System.Drawing.Size(200, 20);
            this.dtpDOB.TabIndex = 8;
            // 
            // txtCRN
            // 
            this.txtCRN.BackColor = System.Drawing.Color.MediumSpringGreen;
            this.txtCRN.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtCRN.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtCRN.Font = new System.Drawing.Font("Modern No. 20", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCRN.Location = new System.Drawing.Point(200, 86);
            this.txtCRN.Name = "txtCRN";
            this.txtCRN.Size = new System.Drawing.Size(188, 14);
            this.txtCRN.TabIndex = 9;
            // 
            // txtCRUN
            // 
            this.txtCRUN.BackColor = System.Drawing.Color.MediumSpringGreen;
            this.txtCRUN.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtCRUN.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtCRUN.Font = new System.Drawing.Font("Modern No. 20", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCRUN.Location = new System.Drawing.Point(200, 133);
            this.txtCRUN.Name = "txtCRUN";
            this.txtCRUN.Size = new System.Drawing.Size(188, 14);
            this.txtCRUN.TabIndex = 10;
            // 
            // txtCRPASSWORD
            // 
            this.txtCRPASSWORD.BackColor = System.Drawing.Color.MediumSpringGreen;
            this.txtCRPASSWORD.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtCRPASSWORD.Font = new System.Drawing.Font("Modern No. 20", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCRPASSWORD.Location = new System.Drawing.Point(200, 167);
            this.txtCRPASSWORD.Name = "txtCRPASSWORD";
            this.txtCRPASSWORD.PasswordChar = '.';
            this.txtCRPASSWORD.Size = new System.Drawing.Size(188, 14);
            this.txtCRPASSWORD.TabIndex = 11;
            // 
            // txtCmail
            // 
            this.txtCmail.BackColor = System.Drawing.Color.MediumSpringGreen;
            this.txtCmail.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtCmail.CharacterCasing = System.Windows.Forms.CharacterCasing.Lower;
            this.txtCmail.Font = new System.Drawing.Font("Modern No. 20", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCmail.Location = new System.Drawing.Point(200, 203);
            this.txtCmail.Name = "txtCmail";
            this.txtCmail.Size = new System.Drawing.Size(188, 14);
            this.txtCmail.TabIndex = 12;
            // 
            // txtCaddress
            // 
            this.txtCaddress.BackColor = System.Drawing.Color.MediumSpringGreen;
            this.txtCaddress.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtCaddress.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtCaddress.Font = new System.Drawing.Font("Modern No. 20", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCaddress.Location = new System.Drawing.Point(200, 246);
            this.txtCaddress.Name = "txtCaddress";
            this.txtCaddress.Size = new System.Drawing.Size(188, 14);
            this.txtCaddress.TabIndex = 13;
            // 
            // rbCMALE
            // 
            this.rbCMALE.AutoSize = true;
            this.rbCMALE.Font = new System.Drawing.Font("Monotype Corsiva", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbCMALE.Location = new System.Drawing.Point(200, 293);
            this.rbCMALE.Name = "rbCMALE";
            this.rbCMALE.Size = new System.Drawing.Size(64, 19);
            this.rbCMALE.TabIndex = 14;
            this.rbCMALE.TabStop = true;
            this.rbCMALE.Text = "MALE";
            this.rbCMALE.UseVisualStyleBackColor = true;
            // 
            // rbCFEMALE
            // 
            this.rbCFEMALE.AutoSize = true;
            this.rbCFEMALE.Font = new System.Drawing.Font("Monotype Corsiva", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbCFEMALE.Location = new System.Drawing.Point(324, 292);
            this.rbCFEMALE.Name = "rbCFEMALE";
            this.rbCFEMALE.Size = new System.Drawing.Size(82, 19);
            this.rbCFEMALE.TabIndex = 15;
            this.rbCFEMALE.TabStop = true;
            this.rbCFEMALE.Text = "FEMALE";
            this.rbCFEMALE.UseVisualStyleBackColor = true;
            // 
            // btCsignUP
            // 
            this.btCsignUP.BackColor = System.Drawing.Color.Teal;
            this.btCsignUP.Font = new System.Drawing.Font("Algerian", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btCsignUP.Location = new System.Drawing.Point(188, 399);
            this.btCsignUP.Name = "btCsignUP";
            this.btCsignUP.Size = new System.Drawing.Size(91, 23);
            this.btCsignUP.TabIndex = 16;
            this.btCsignUP.Text = "SIGN UP";
            this.btCsignUP.UseVisualStyleBackColor = false;
            this.btCsignUP.Click += new System.EventHandler(this.btCsignUP_Click);
            // 
            // lbCRback
            // 
            this.lbCRback.AutoSize = true;
            this.lbCRback.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCRback.ForeColor = System.Drawing.Color.OliveDrab;
            this.lbCRback.Location = new System.Drawing.Point(209, 434);
            this.lbCRback.Name = "lbCRback";
            this.lbCRback.Size = new System.Drawing.Size(55, 18);
            this.lbCRback.TabIndex = 17;
            this.lbCRback.Text = "BACK";
            this.lbCRback.Click += new System.EventHandler(this.lbCRback_Click);
            // 
            // customerResistrationPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightGreen;
            this.ClientSize = new System.Drawing.Size(434, 511);
            this.Controls.Add(this.lbCRback);
            this.Controls.Add(this.btCsignUP);
            this.Controls.Add(this.rbCFEMALE);
            this.Controls.Add(this.rbCMALE);
            this.Controls.Add(this.txtCaddress);
            this.Controls.Add(this.txtCmail);
            this.Controls.Add(this.txtCRPASSWORD);
            this.Controls.Add(this.txtCRUN);
            this.Controls.Add(this.txtCRN);
            this.Controls.Add(this.dtpDOB);
            this.Controls.Add(this.lbCDOB);
            this.Controls.Add(this.lbCGENDER);
            this.Controls.Add(this.lbCaddress);
            this.Controls.Add(this.lbCemail);
            this.Controls.Add(this.lbCRPASSWORD);
            this.Controls.Add(this.lbCRUN);
            this.Controls.Add(this.lbCRN);
            this.Controls.Add(this.lbCR);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "customerResistrationPage";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "customerResistrationPage";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbCR;
        private System.Windows.Forms.Label lbCRN;
        private System.Windows.Forms.Label lbCRUN;
        private System.Windows.Forms.Label lbCRPASSWORD;
        private System.Windows.Forms.Label lbCemail;
        private System.Windows.Forms.Label lbCaddress;
        private System.Windows.Forms.Label lbCGENDER;
        private System.Windows.Forms.Label lbCDOB;
        private System.Windows.Forms.DateTimePicker dtpDOB;
        private System.Windows.Forms.TextBox txtCRN;
        private System.Windows.Forms.TextBox txtCRUN;
        private System.Windows.Forms.TextBox txtCRPASSWORD;
        private System.Windows.Forms.TextBox txtCmail;
        private System.Windows.Forms.TextBox txtCaddress;
        private System.Windows.Forms.RadioButton rbCMALE;
        private System.Windows.Forms.RadioButton rbCFEMALE;
        private System.Windows.Forms.Button btCsignUP;
        private System.Windows.Forms.Label lbCRback;
    }
}